//Quick_sort
#include <iostream>
using namespace std;

int partition(int* arr, int start, int end)
{
    int pivotLocation = start;
    int pivot = arr[end];
    for (int i = start; i < end; i++)
    {
        if (arr[i] < pivot)
        {
            swap(arr[pivotLocation], arr[i]);
            pivotLocation++;
        }
    }
    swap(arr[pivotLocation], arr[end]);
    return pivotLocation;
}
void quickSort(int* arr, int start, int end)
{
    if (start >= end)
        return;
    int pivotLocation = partition(arr, start, end);
    quickSort(arr, start, pivotLocation - 1);
    quickSort(arr, pivotLocation + 1, end);
}

int main()
{
   
    int n, i;
    cout << "enter no of elements of array\n";
    cin >> n;
    int arr[30];
    for (i = 1; i <= n; i++) {
        cout << "enter elements" << " " << (i) << endl;
        cin >> arr[i];
    }
    int partition(int* arr, int start, int end);
    quickSort(arr, 0, n);
    for (i = 1; i <= n; i++) {
        cout << arr[i] << endl;
    }
    return 0;
}